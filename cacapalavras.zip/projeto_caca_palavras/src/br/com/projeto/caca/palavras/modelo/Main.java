package br.com.projeto.caca.palavras.modelo;

public class Main {

	public static void main(String[] args) {
	
		
	}

}
